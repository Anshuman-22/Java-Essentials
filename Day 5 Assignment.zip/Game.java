package com.Quiz;

import com.Quiz.playername;
import com.Quiz.question;


public class Game {
playername player =new playername();


question [] questions = new question [3];

public void initGame(){
  for (int i=0; i<3; i++){
    
    questions[i]= new question();
  } 
  
  
questions[0].question = "Who is the current IPL official sponsor?";
questions[0].opt1= "Vivo";
questions[0].opt2= "Dream 11";
questions[0].opt3= "Oppo";
questions[0].opt4= "DLF";
questions[0].correctans=2;

questions[1].question = "IPL 2020's Venue Is?";
questions[1].opt1= "Dubai";
questions[1].opt2= "Eng";
questions[1].opt3= "Hydrbad";
questions[1].opt4= "Mumbai";
questions[1].correctans=1;

questions[2].question = "Which Team in IPL has most trophies?";
questions[2].opt1= "KKR";
questions[2].opt2= "MI";
questions[2].opt3= "KXIP";
questions[2].opt4= "CSK";
questions[2].correctans= 2;

}

public void play(){
player.getDetails();
for (int i=0;i<3;i++){
 boolean status = questions[i].askQuestion();

  
  if (status==true){
  System.out.println("Amazing!!! You Are Right");
  player.score++;
  }
  else {
    System.out.println("Sorry You Are Wrong");
  }
  }
  if (player.score==1)
  {
    System.out.println("You Got 2 Ans Wrong");
   
  }
  else if (player.score==2){
  System.out.println("You Got 1 Ans Wrong");
    
  }
  else if (player.score==3){
    System.out.println("OMG! You Are Pro All Ans Are Correct");
  }
  else if (player.score==0){
    System.out.println(" Hah Noob You Got All Questions Wrong");
  }
  System.out.println(player.name + 
  " Your Score " 
  +player.score);
  
  }
  }
  
  
  
  
  
    



