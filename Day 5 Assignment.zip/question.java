package com.Quiz;
import java.util.Scanner;

public class question {
Scanner sc=new Scanner (System.in);
String question, opt1, opt2, opt3, opt4;
int correctans;
int userans;
public boolean askQuestion(){


 System.out.println(question);
 System.out.println("1." +opt1);
 System.out.println("2." +opt2);
 System.out.println("3." +opt3);
 System.out.println("4." +opt4);
 System.out.println("Please Choose The Correct Answer +1 For Each Correct Answer" );
 userans=sc.nextInt();
 if (userans==correctans){
   return true;
 }
 
 return false;
  
}




}
