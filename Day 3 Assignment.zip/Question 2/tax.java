package com.anshu;

import java.util.Scanner;

public class tax {
public static void main(String [] args) {
  
  Scanner sc=new Scanner(System.in);
  String name;
  int dob, mob, yob, ms, as;
  
  
  System.out.println("Enter your Details below");
  System.out.print("Enter your name: ");
  name=sc.nextLine();
  System.out.print("Enter your date of birth: ");
  dob=sc.nextInt();
  System.out.print("Enter your month of birth: ");
  mob=sc.nextInt();
  System.out.print("Enter your year of birth: ");
  yob=sc.nextInt();
  System.out.print("Enter your monthly salary: ");
  ms=sc.nextInt();
  
  as = (ms * 12);
  
  System.out.println("Your name is " + name);
  
  if (yob==1990){
   System.out.println("Your age is 30 years");
 }
 
 else if (yob==1991){
   System.out.println("Your age is 29 years");
 }
  
 else if (yob==1992){
   System.out.println("Your age is 28 years");
 }
  
 else if (yob==1993){
   System.out.println("Your age is 27 years");
 }
   
 else if (yob==1994){
   System.out.println("Your age is 26 years");
 }
   
 else if (yob==1995){
   System.out.println("Your age is 25 years");
 }
    
 else if (yob==1996){
   System.out.println("Your age is 24 years");
 }
    
 else if (yob==1997){
   System.out.println("Your age is 23 years");
 }
    
 else if (yob==1998){
   System.out.println("Your age is 22 years");
 }
    
 else if (yob==1999){
   System.out.println("Your age is 21 years");
 }
   
 else if (yob==2000){
   System.out.println("Your age is 20 years");
 }
   
 else if (yob==2001){
   System.out.println("Your age is 19 years");
 }
    
 else if (yob==2002){
   System.out.println("Your age is 18 years");
 }
      
 else{
   System.out.println("please specify year after 1989");
 }
  
   System.out.println("Your annual salary is INR "+as);
 
  
 if(as>=500000){
   System.out.println("You have to pay 20% tax");
 }
 
 else if(as>=400000 && as<500000){
   System.out.println("You have to pay 15% tax");
 }
 
 else if (as>=300000 && as<400000){
   System.out.println("You have to pay 10% tax");
 }
 
 else if (as>=200000 && as<300000){
   System.out.println("You have to pay 5% tax");
 }
 
 else {
   System.out.println("You don't have to pay tax");
 }
  
  }


}
