package com.main;

import com.main.employee;

public class main {

  public static void main(String[] args) {
   
   employee e = new employee ();
   e.name = "Anshu";
   e.age=22;
   e.city="Kolkata";
   e.display();
  
   
   
   employee e1= new employee();
   e1.name="Roshan";
   e1.age=24;
   e1.city="Kolkata";
   e1.display();
   
   
  }
 }