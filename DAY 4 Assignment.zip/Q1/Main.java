package com.main;

import com.main.avengers;


public class Main {

  public static void main(String[] args) {
  
  
  avengers[] avg =new avengers [5];
  for (int i=0;i<5;i++){
    avg [i] = new avengers();
  }
  
    for (int i=0;i<5;i++){
    avg [i].getDetails();
     avg [i].displayDetails();
    
  }
   
  }
}
